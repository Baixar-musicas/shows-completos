


// Country

function opennomecidade12(nomecidade,elmnt,color) {

  var seila, conteudo14, aba12;
  conteudo14 = document.getElementsByClassName("conteudo14");
  for (seila = 0; seila < conteudo14.length; seila++) {
    conteudo14[seila].style.display = "none";
  }

  aba12 = document.getElementsByClassName("aba12");
  for (seila = 0; seila < aba12.length; seila++) {
    aba12[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("decimoterceiro").click();



// Eletrônicas

function opennomecidade11(nomecidade,elmnt,color) {

  var seila, conteudo13, aba11;
  conteudo13 = document.getElementsByClassName("conteudo13");
  for (seila = 0; seila < conteudo13.length; seila++) {
    conteudo13[seila].style.display = "none";
  }

  aba11 = document.getElementsByClassName("aba11");
  for (seila = 0; seila < aba11.length; seila++) {
    aba11[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("decimosegundo").click();




// Gospel

function opennomecidade10(nomecidade,elmnt,color) {

  var seila, conteudo12, aba10;
  conteudo12 = document.getElementsByClassName("conteudo12");
  for (seila = 0; seila < conteudo12.length; seila++) {
    conteudo12[seila].style.display = "none";
  }

  aba10 = document.getElementsByClassName("aba10");
  for (seila = 0; seila < aba10.length; seila++) {
    aba10[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("decimoprimeiro").click();




// Rock

function opennomecidade09(nomecidade,elmnt,color) {

  var seila, conteudo11, aba09;
  conteudo11 = document.getElementsByClassName("conteudo11");
  for (seila = 0; seila < conteudo11.length; seila++) {
    conteudo11[seila].style.display = "none";
  }

  aba09 = document.getElementsByClassName("aba09");
  for (seila = 0; seila < aba09.length; seila++) {
    aba09[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("decimo").click();




// Brega

function opennomecidade08(nomecidade,elmnt,color) {

  var seila, conteudo10, aba08;
  conteudo10 = document.getElementsByClassName("conteudo10");
  for (seila = 0; seila < conteudo10.length; seila++) {
    conteudo10[seila].style.display = "none";
  }

  aba08 = document.getElementsByClassName("aba08");
  for (seila = 0; seila < aba08.length; seila++) {
    aba08[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("nono").click();




// Sertanejo

function opennomecidade07(nomecidade,elmnt,color) {

  var seila, conteudo09, aba07;
  conteudo09 = document.getElementsByClassName("conteudo09");
  for (seila = 0; seila < conteudo09.length; seila++) {
    conteudo09[seila].style.display = "none";
  }

  aba07 = document.getElementsByClassName("aba07");
  for (seila = 0; seila < aba07.length; seila++) {
    aba07[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("oitavo").click();






// Samba e Pagode

function opennomecidade06(nomecidade,elmnt,color) {

  var seila, conteudo08, aba06;
  conteudo08 = document.getElementsByClassName("conteudo08");
  for (seila = 0; seila < conteudo08.length; seila++) {
    conteudo08[seila].style.display = "none";
  }

  aba06 = document.getElementsByClassName("aba06");
  for (seila = 0; seila < aba06.length; seila++) {
    aba06[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("setimo").click();







// Pop

function opennomecidade05(nomecidade,elmnt,color) {

  var seila, conteudo07, aba05;
  conteudo07 = document.getElementsByClassName("conteudo07");
  for (seila = 0; seila < conteudo07.length; seila++) {
    conteudo07[seila].style.display = "none";
  }

  aba05 = document.getElementsByClassName("aba05");
  for (seila = 0; seila < aba05.length; seila++) {
    aba05[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("sexto").click();








// MPB

function opennomecidade04(nomecidade,elmnt,color) {

  var seila, conteudo06, aba04;
  conteudo06 = document.getElementsByClassName("conteudo06");
  for (seila = 0; seila < conteudo06.length; seila++) {
    conteudo06[seila].style.display = "none";
  }

  aba04 = document.getElementsByClassName("aba04");
  for (seila = 0; seila < aba04.length; seila++) {
    aba04[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("quinto").click();






// Internacional

function opennomecidade03(nomecidade,elmnt,color) {

  var seila, conteudo05, aba03;
  conteudo05 = document.getElementsByClassName("conteudo05");
  for (seila = 0; seila < conteudo05.length; seila++) {
    conteudo05[seila].style.display = "none";
  }

  aba03 = document.getElementsByClassName("aba03");
  for (seila = 0; seila < aba03.length; seila++) {
    aba03[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("quarto").click();






// Funk

function opennomecidade02(nomecidade,elmnt,color) {

  var seila, conteudo04, aba02;
  conteudo04 = document.getElementsByClassName("conteudo04");
  for (seila = 0; seila < conteudo04.length; seila++) {
    conteudo04[seila].style.display = "none";
  }

  aba02 = document.getElementsByClassName("aba02");
  for (seila = 0; seila < aba02.length; seila++) {
    aba02[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("terceiro").click();






// Forró

function opennomecidade01(nomecidade,elmnt,color) {

  var seila, conteudo03, aba01;
  conteudo03 = document.getElementsByClassName("conteudo03");
  for (seila = 0; seila < conteudo03.length; seila++) {
    conteudo03[seila].style.display = "none";
  }

  aba01 = document.getElementsByClassName("aba01");
  for (seila = 0; seila < aba01.length; seila++) {
    aba01[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("segundo").click();





// Axé

function opennomecidade(nomecidade,elmnt,color) {

  var seila, conteudo02, aba;
  conteudo02 = document.getElementsByClassName("conteudo02");
  for (seila = 0; seila < conteudo02.length; seila++) {
    conteudo02[seila].style.display = "none";
  }

  aba = document.getElementsByClassName("aba");
  for (seila = 0; seila < aba.length; seila++) {
    aba[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("primeiro").click();








function openCity(evt, cityName) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();






document.getElementById("concluir03").onclick = function senha03() {
  var senha03 = 'alsh24-eh1020';
  var senhadig = document.getElementById("senha03").value;

  if (senha03 == senhadig){
    document.getElementById("over03").style.display="none"
  }else if (senha03 != senhadig){
    window.location.href='https://packdemusicas.com.br/premium/shows.html';
  }
}